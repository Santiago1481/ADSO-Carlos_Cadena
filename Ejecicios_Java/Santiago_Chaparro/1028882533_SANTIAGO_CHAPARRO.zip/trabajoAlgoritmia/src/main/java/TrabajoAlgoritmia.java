/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

/**
 *
 * @author Santiago Chaparro
 */
public class TrabajoAlgoritmia {

    public static void main(String[] args) {
        //ejercicios
        /*
        Conversión de temperatura: Escribe un programa que 
        convierta una temperatura ingresada en grados Celsius a 
        Fahrenheit y Kelvin.
        */
        var cel = 0;
        var faren = 0;
        var kel = 0.1f;
        
        faren = (9*cel)/5+32;
        kel = cel + 273.15f;
        
        System.out.println("La temeperatura ingresada en grados Celcius es: " + cel);
        System.out.println("La temperatura ingresada en grados Celsius a Fahrenheit es: " + faren);
        System.out.println("La temperatura ingresada en grados Celsius a Kelvin es: " + kel);
        
        
        /*Cálculo del IMC: Pide al usuario su peso (kg) y altura (m),
        y calcula su Índice de Masa Corporal (IMC).*/
        
        float peso = 99.95f;
        float altura = 1.69f;
        float masaCorporal =  peso/(float) Math.pow(altura, 2);
        //Math.pow(base, exponente) liberia de matematicas
        System.out.println("El calculo del IMC del peso "+peso+"kl y altura "+altura+" es: "+masaCorporal);
        
        
        /*
        Área y perímetro de un triángulo:
        Solicita la base y la altura de un triángulo
        y calcula su área y perímetro.
        */
                
        float area = 0;
        float perimetro = 0;
        float base = 11.3f;
        float alturaa = 17.6f;
        area = (base*alturaa)/2;
        perimetro = 2*(base*alturaa);
        System.out.println("el area "+area);
        System.out.println("el perimetro "+perimetro);
        
        
        /*Operaciones con dos números: 
        Pide dos números al usuario y muestra
        la suma, resta, multiplicación, división y módulo.
        */
        int num21 = 5;
        int num22 = 5;
        var suma = (num21+num22);
        var resta = num21-num22;
        var multi = num21*num22;
        var div = num21/num22;
        System.out.println("la suma de " + num21 + " + " + num22 + " es: " + suma);
        System.out.println("la resta de " + num21 + " - " + num22 + " es: " + resta);
        System.out.println("la multiplicacion de " + num21 + " x " + num22 + " es: " + multi);
        System.out.println("la divicion de " + num21 + " / " + num22 + " es: " + div);
        
        /*Intercambio de valores: 
        Solicita dos valores y los intercambia sin usar una variable auxiliar
        */
        
        var A = 5;
        var B = 10;
        
        System.out.println("Valor A: "+A);
        System.out.println("Valor B: "+B);
        A = A + B;
        A = A + A;
        A = A / 3;
        B = A / 2;
        
        System.out.println("valor A: "+A);
        System.out.println("Valor B: "+B);
        
        // condicionales 
        /*
        Número positivo, negativo o cero:
        Pide un número al usuario e indica si es positivo, negativo o cero.
        */
        
        int numero = 0;
        if (numero == 0){
            System.out.println("El numero es cero");
        }else{
            if(numero > 0){
                System.out.println("El numero es posotivo");
            }else{
                System.out.println("El numero es negativo");
            }
        }
        
        
        /*
        Mayor de tres números: Solicita tres números e imprime cuál es el mayor.
        */
        
        int numero1 = 10;
        int numero2 = 11;
        int numero3 = 12;
        
        if(numero1 > numero2 || numero1 > numero3){
            System.out.println("El numero uno es mayor");
        } else{
            if(numero2 > numero1 || numero2 > numero3){
                    System.out.println("El numero 2 es mayor"); 
            } else{
                if(numero3 > numero1  || numero3 > numero2){
                    System.out.println("El numero 3 es mayor");
                } else{
                    System.out.println("Los tres numeros son iguales");
                }
                
            }
        }
        
        /*Año bisiesto: Pide un año y determina si es bisiesto o no.
        */
        
        var año = 2024;
         if(año < 2025){
             if ((año % 4 == 0 && año % 100 != 0) || (año % 400 == 0)) {
                 System.out.println("El año: "+año+" es bisiesto");
             } else{
                 System.out.println("El año: "+año+" no es bisiesto");
             }
         } else{
             System.out.println("Ese año no existe ");
         }
        
        /*Calculadora simple: Pide dos números 
         y una operación (+, -, *, /) e imprime el resultado.
         */
        
        double num1 = 10; 
        double num2 = 5;  
        char operacion = '+'; 
        double resultado = 0;

        // Usando switch para realizar la operación
        switch (operacion) {
            case '+':
                resultado = num1 + num2;
                break;
            case '-':
                resultado = num1 - num2;
                break;
            case '*':
                resultado = num1 * num2;
                break;
            case '/':
                if (num2 != 0) {
                    resultado = num1 / num2;
                } else {
                    System.out.println("Error: División por cero.");
                    return;
                }
                break;
            default:
                System.out.println("Operación no válida.");
                return;
        }
        System.out.println("Resultado: " + resultado);
        
        
        /*Clasificación de triángulos: Pide los lados de un  
        triángulo e indica si es equilátero, isósceles o escaleno.
        */
        
        double lado1 = 5;
        double lado2 = 5;
        double lado3 = 5;
        String tipo = "";

        // Verificar si los lados forman un triángulo válido
        if (lado1 + lado2 > lado3 && lado1 + lado3 > lado2 && lado2 + lado3 > lado1) {
            // Clasificación con switch
            if (lado1 == lado2 && lado2 == lado3) {
                tipo = "Equilátero";
            } else if (lado1 == lado2 || lado1 == lado3 || lado2 == lado3) {
                tipo = "Isósceles";
            } else {
                tipo = "Escaleno";
            }
        } else {
            tipo = "No es un triángulo válido";
        }

        // Evaluar resultado en switch
        switch (tipo) {
            case "Equilátero":
                System.out.println("El triángulo es Equilátero.");
                break;
            case "Isósceles":
                System.out.println("El triángulo es Isósceles.");
                break;
            case "Escaleno":
                System.out.println("El triángulo es Escaleno.");
                break;
            default:
                System.out.println("No es un triángulo válido.");
                break;
        }
        
        /*Tabla de multiplicar: Pide un número 
        y muestra su tabla de multiplicar del 1 al 10.
        */
        
        // Número quemado para la tabla de multiplicar
        int numeroBase = 7;
        int multiplicador;

        // Usando for
        System.out.println("Tabla de multiplicar del " + numeroBase + " usando for:");
        for (multiplicador = 1; multiplicador <= 10; multiplicador++) {
            int resultados = numeroBase * multiplicador;
            System.out.println(numeroBase + " x " + multiplicador + " = " + resultado);
        }

        // Usando while
        System.out.println("\nTabla de multiplicar del " + numeroBase + " usando while:");
        multiplicador = 1;
        while (multiplicador <= 10) {
            int resultados = numeroBase * multiplicador;
            System.out.println(numeroBase + " x " + multiplicador + " = " + resultado);
            multiplicador++;
        }

        // Usando do-while
        System.out.println("\nTabla de multiplicar del " + numeroBase + " usando do-while:");
        multiplicador = 1;
        do {
            int resultados = numeroBase * multiplicador;
            System.out.println(numeroBase + " x " + multiplicador + " = " + resultado);
            multiplicador++;
        } while (multiplicador <= 10);
        
        
        
        /*Suma de N números: Solicita un número
        N y suma los primeros N números naturales.
        */

        int cantidadNumeros = 10;
        int sumaTotal = 0;
        int numeroActual;

        // Usando for
        System.out.println("Suma de los primeros " + cantidadNumeros + " números usando for:");
        sumaTotal = 0;
        for (numeroActual = 1; numeroActual <= cantidadNumeros; numeroActual++) {
            sumaTotal += numeroActual;
        }
        System.out.println("Resultado: " + sumaTotal);

        // Usando while
        System.out.println("\nSuma de los primeros " + cantidadNumeros + " números usando while:");
        sumaTotal = 0;
        numeroActual = 1;
        while (numeroActual <= cantidadNumeros) {
            sumaTotal += numeroActual;
            numeroActual++;
        }
        System.out.println("Resultado: " + sumaTotal);

        // Usando do-while
        System.out.println("\nSuma de los primeros " + cantidadNumeros + " números usando do-while:");
        sumaTotal = 0;
        numeroActual = 1;
        do {
            sumaTotal += numeroActual;
            numeroActual++;
        } while (numeroActual <= cantidadNumeros);
        System.out.println("Resultado: " + sumaTotal);
        
        
        /*Contador de dígitos: Pide un número
        entero y cuenta cuántos dígitos tiene.
        */
        
        int numeroContar = 8;
        int contador = 0;

        
        while (contador == numeroContar){
            System.out.println("Numero: " + contador);
            contador = +1;
            System.out.println(contador);
        }
        
        /*Serie Fibonacci: Imprime los primeros
        N términos de la serie de Fibonacci.
        */
        
        int cantidadTerminos = 10;
        int primerTermino = 0;
        int segundoTermino = 1;
        int siguienteTermino;

        // Usando for
        System.out.println("Serie de Fibonacci usando for:");
        for (int i = 1; i <= cantidadTerminos; i++) {
            System.out.print(primerTermino + " ");
            siguienteTermino = primerTermino + segundoTermino;
            primerTermino = segundoTermino;
            segundoTermino = siguienteTermino;
        }
        System.out.println();

        // Usando while
        System.out.println("\nSerie de Fibonacci usando while:");
        primerTermino = 0;
        segundoTermino = 1;
        int contadorWhile = 1;
        while (contadorWhile <= cantidadTerminos) {
            System.out.print(primerTermino + " ");
            siguienteTermino = primerTermino + segundoTermino;
            primerTermino = segundoTermino;
            segundoTermino = siguienteTermino;
            contadorWhile++;
        }
        System.out.println();

        // Usando do-while
        System.out.println("\nSerie de Fibonacci usando do-while:");
        primerTermino = 0;
        segundoTermino = 1;
        int contadorDoWhile = 1;
        do {
            System.out.print(primerTermino + " ");
            siguienteTermino = primerTermino + segundoTermino;
            primerTermino = segundoTermino;
            segundoTermino = siguienteTermino;
            contadorDoWhile++;
        } while (contadorDoWhile <= cantidadTerminos);
        System.out.println();
        
        
        /*Números primos en un rango:
        Solicita un número límite y muestra todos los primos hasta ese número.
        */
        
        int limite = 30;

        // Usando for
        System.out.println("Números primos hasta " + limite + " usando for:");
        for (int i = 2; i <= limite; i++) {
            if (esPrimo(i)) {
                System.out.print(i + " ");
            }
        }
        System.out.println();

        // Usando while
        System.out.println("\nNúmeros primos hasta " + limite + " usando while:");
        int contadorWhile1 = 2;
        while (contadorWhile <= limite) {
            if (esPrimo(contadorWhile)) {
                System.out.print(contadorWhile + " ");
            }
            contadorWhile++;
        }
        System.out.println();

        // Usando do-while
        System.out.println("\nNúmeros primos hasta " + limite + " usando do-while:");
        int contadorDoWhile1 = 2;
        do {
            if (esPrimo(contadorDoWhile)) {
                System.out.print(contadorDoWhile + " ");
            }
            contadorDoWhile++;
        } while (contadorDoWhile <= limite);
        System.out.println();
    }

    // Método sencillo para verificar si un número es primo
    public static boolean esPrimo(int numero) {
        for (int i = 2; i < numero; i++) {
            if (numero % i == 0) {
                return false; // No es primo
            }
        }
        return numero > 1;
    }
}
